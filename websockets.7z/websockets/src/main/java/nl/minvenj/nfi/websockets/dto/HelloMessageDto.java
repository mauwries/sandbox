package nl.minvenj.nfi.websockets.dto;

import lombok.AllArgsConstructor;
import lombok.Getter;

@Getter
@AllArgsConstructor
public class HelloMessageDto {
    private String name;
}
