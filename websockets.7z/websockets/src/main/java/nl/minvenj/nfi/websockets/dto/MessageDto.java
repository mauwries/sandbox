package nl.minvenj.nfi.websockets.dto;

public record MessageDto(String message) {

}
