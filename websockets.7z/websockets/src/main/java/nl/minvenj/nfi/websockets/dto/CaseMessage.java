package nl.minvenj.nfi.websockets.dto;

public record CaseMessage(String caseNumber, String message) {
}
