package nl.minvenj.nfi.websockets.dto;

public record MessageFromUserDto(String name, String message) {
}
